/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author dkdri
 */
public class C {
    
    private static final String URL = "jdbc:mysql://localhost/webservice";
    private static final String DRIVER = "con.mysql.jdbc.Driver";
    private static final String USER = "root";
    private static final String SENHA = "";
    
    private static Connection con;
    
    public static Connection cb() throws ClassNotFoundException, SQLException{
        Class.forName(DRIVER);
        con = (Connection) DriverManager.getConnection(URL,USER,SENHA);
        return con;
    }
    
    public static void db() throws SQLException{
        con.close();
    }
    
}
